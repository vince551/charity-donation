// js/app.js
import { showNotification } from './notifications.js';

document.addEventListener('DOMContentLoaded', () => {
  console.log("Pitch Kings DLS System initialized.");
});