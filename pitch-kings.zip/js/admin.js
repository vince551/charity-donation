// js/admin.js
import { db } from './firebase.js';
import { collection, getDocs } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

export async function fetchDashboardStats() {
  try {
    const tSnap = await getDocs(collection(db, "tournaments"));
    const teamsSnap = await getDocs(collection(db, "teams"));
    const mSnap = await getDocs(collection(db, "fixtures"));

    document.getElementById('count-tournaments').textContent = tSnap.size;
    document.getElementById('count-teams').textContent = teamsSnap.size;
    document.getElementById('count-matches').textContent = mSnap.size;
  } catch (err) {
    console.error("Error fetching stats:", err);
  }
}