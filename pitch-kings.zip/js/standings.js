// js/standings.js
import { db } from './firebase.js';
import { collection, getDocs } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

export async function loadStandings(tableBodyId = 'standingsList') {
  const tableBody = document.getElementById(tableBodyId);
  if (!tableBody) return;

  tableBody.innerHTML = '<tr><td colspan="8">Calculating standings...</td></tr>';

  try {
    const snapshot = await getDocs(collection(db, "teams"));
    tableBody.innerHTML = '';

    if (snapshot.empty) {
      tableBody.innerHTML = '<tr><td colspan="8">No teams available.</td></tr>';
      return;
    }

    const teams = [];
    snapshot.forEach((docSnap) => teams.push({ id: docSnap.id, ...docSnap.data() }));

    // Sort teams by Points -> Goal Difference -> Goals For
    teams.sort((a, b) => (b.points || 0) - (a.points || 0) || (b.gd || 0) - (a.gd || 0));

    teams.forEach((team, index) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${index + 1}</td>
        <td><strong>${team.name}</strong></td>
        <td>${team.played || 0}</td>
        <td>${team.won || 0}</td>
        <td>${team.drawn || 0}</td>
        <td>${team.lost || 0}</td>
        <td>${team.gd || 0}</td>
        <td><strong>${team.points || 0}</strong></td>
      `;
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Error loading standings:", error);
  }
}