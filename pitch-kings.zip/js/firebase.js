// js/firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-analytics.js";

const firebaseConfig = {
  apiKey: "AIzaSyBm4SRxqzEYIpt6ZPl_KpxAxDOlb31i5nw",
  authDomain: "pitch-kings.firebaseapp.com",
  projectId: "pitch-kings",
  storageBucket: "pitch-kings.firebasestorage.app",
  messagingSenderId: "287474189765",
  appId: "1:287474189765:web:d6222becec8e9c2a3777ac",
  measurementId: "G-CS6EX26NJ9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Analytics (optional)
const analytics = getAnalytics(app);

// Initialize and EXPORT Auth and Firestore for your other JS modules
export const auth = getAuth(app);
export const db = getFirestore(app);