// js/users.js
import { db } from './firebase.js';
import { collection, getDocs } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

export async function loadUsers() {
  const container = document.getElementById('usersList');
  if (!container) return;

  container.innerHTML = '<tr><td colspan="3">Loading...</td></tr>';

  try {
    const snapshot = await getDocs(collection(db, "users"));
    container.innerHTML = '';

    if (snapshot.empty) {
      container.innerHTML = '<tr><td colspan="3">No registered users found.</td></tr>';
      return;
    }

    snapshot.forEach(docSnap => {
      const data = docSnap.data();
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${data.email || 'N/A'}</td>
        <td>${data.role || 'user'}</td>
        <td><button style="color:red; background:none; border:none; cursor:pointer;">Remove</button></td>
      `;
      container.appendChild(row);
    });
  } catch (err) {
    container.innerHTML = '<tr><td colspan="3">Error loading users.</td></tr>';
  }
}